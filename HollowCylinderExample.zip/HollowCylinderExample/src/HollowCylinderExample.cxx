#include <vtkActor.h>
#include <vtkCylinderSource.h>
#include <vtkNamedColors.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSmartPointer.h>


int main(int, char *[]) {
  vtkSmartPointer<vtkNamedColors> colors =
      vtkSmartPointer<vtkNamedColors>::New();

//big cylinder----
  vtkSmartPointer<vtkCylinderSource> cylinderBig =
      vtkSmartPointer<vtkCylinderSource>::New();
	  cylinderBig->SetCenter(0.0, 0.0, 0.0);
	  cylinderBig->SetRadius(6.0);
      cylinderBig->SetHeight(9.0);
      cylinderBig->SetResolution(100);
  
  vtkSmartPointer<vtkPolyDataMapper> cylinderBigMapper =
      vtkSmartPointer<vtkPolyDataMapper>::New();
  cylinderBigMapper->SetInputConnection(cylinderBig->GetOutputPort());

  vtkSmartPointer<vtkActor> cylinderBigActor = vtkSmartPointer<vtkActor>::New();
  cylinderBigActor->SetMapper(cylinderBigMapper);
  cylinderBigActor->GetProperty()->SetColor(
      colors->GetColor4d("Tomato").GetData());
	  cylinderBigActor->GetProperty()->SetOpacity(.7);
  cylinderBigActor->RotateX(30.0);
  cylinderBigActor->RotateY(-45.0);
  
  vtkSmartPointer<vtkRenderer> rendererBig = vtkSmartPointer<vtkRenderer>::New();
  rendererBig->AddActor(cylinderBigActor);
  
  ///small cylinder--------
    vtkSmartPointer<vtkCylinderSource> cylinderSmall =
      vtkSmartPointer<vtkCylinderSource>::New();
	  cylinderSmall->SetCenter(0.0, 0.0, 0.0);
	  cylinderSmall->SetRadius(3.0);
      cylinderSmall->SetHeight(9.0);
      cylinderSmall->SetResolution(100);
  
  vtkSmartPointer<vtkPolyDataMapper> cylinderSmallMapper =
      vtkSmartPointer<vtkPolyDataMapper>::New();
  cylinderSmallMapper->SetInputConnection(cylinderSmall->GetOutputPort());

  vtkSmartPointer<vtkActor> cylinderSmallActor = vtkSmartPointer<vtkActor>::New();
  cylinderSmallActor->SetMapper(cylinderSmallMapper);
  cylinderSmallActor->GetProperty()->SetColor(
      colors->GetColor4d("Seashell").GetData());
  cylinderSmallActor->RotateX(30.0);
  cylinderSmallActor->RotateY(-45.0);
  
  vtkSmartPointer<vtkRenderer> rendererSmall = vtkSmartPointer<vtkRenderer>::New();
  rendererSmall->AddActor(cylinderSmallActor);
  ///end small cylinder------ 
  

  //========Render==Rendererwindow====Interactor=======
  vtkSmartPointer<vtkRenderer> renderer =
  vtkSmartPointer<vtkRenderer>::New();
  vtkSmartPointer<vtkRenderWindow> renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);
  vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);
// adding actor to screen
  renderer->AddActor(cylinderSmallActor);
  renderer->AddActor(cylinderBigActor);
  
 //background color
  renderer->SetBackground(colors->GetColor3d("Cornsilk").GetData());
  
  renderWindow->Render();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}